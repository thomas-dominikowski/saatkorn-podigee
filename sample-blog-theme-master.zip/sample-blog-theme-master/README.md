# Sample Blog Theme
Sample repo that allows to use external files in Podigee blog themes.

The top-level `files` directory is mandatory for a successful import of the theme files.

You'll find more detailed instructions here:

https://help.podigee.com/article/160-importing-themes-from-git-repos


---

## About us

**Podigee** is a podcast hosting software as a service. We help podcasters big and small getting their content out to their listeners as easy as possible. Find out more about us here: https://www.podigee.com/en/
